/******************************************************************
 *   MISRA-C conformance suite.
 *
 *   Copyright:     2001-, Motor Industry Research Association.
 *                  http://www.misra.org.uk/
 *
 *   MISRA is a registered trademark of the Motor Industry Research
 *   Association.
 ******************************************************************
 *   This is part of the official MISRA-C conformance suite.
 *
 *   Acknowledgements:-
 *
 *   This suite is an ongoing project.  It contains source code
 *   and ideas donated in alphabetic order by:-
 *        Andrew Burnard           Land Rover
 *        Les Hatton               Oakwood Computing Associates Ltd.
 *                                 and the University of Kent.
 *        Derek Jones              Knowledge Software Ltd.
 *
 *   In addition, valuable feedback and guidance was provided by
 *   other members of the MISRA steering committee in alphabetic order:-
 *        Paul Burden, Chris Hills, Gavin McCall, Olwen Morgan
 *
 *   Conformance architecture and rule merging done by
 *        Les Hatton               L.Hatton@ukc.ac.uk
 *
 *   Produced and maintained as a project under the auspices of the
 *   Systems and Software Engineering Research Group, Computing
 *   Laboratory, University of Kent, Canterbury, CT2 7NZ, U.K.
 ******************************************************************
 *   Please forward all comments and feedback to Les Hatton.
 ******************************************************************
 *   Distribution:
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation.
 *   
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *   
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA  02111-1307  USA.
 *
 *   PLEASE NOTE THAT THE MASTER COPIES MAINTAINED BY MISRA
 *   CONTAIN AN IDENTIFYING DIGITAL SIGNATURE TO FACILITATE
 *   CONFORMANCE AND EMBEDDED BELOW.
 ******************************************************************
 *DS Digital Signature: 38678
 ******************************************************************/

/******************************************************************
 *   POSITIVE RULE.  A tool must detect the occurrences marked:-
 *
 *   MRULE parenthesized by #...#  followed by the rule number.
 *   This pattern is used by the conformance suite infrastructure
 *   to build a calibration compliance matrix.
 ******************************************************************/

/******************************************************************
 *   Revision: $Revision: 1.2 $
 *   Date:     $Date: 2002/06/25 14:51:14 $
 ******************************************************************/

/******************************************************************
 *   MISRA header explicitly embedded by MISRA Conformance architecture.
 *   Revision: $Revision: 1.2 $
 *   Date:     $Date: 2001/06/22 14:42:06 $
 ******************************************************************/
/*
 *   A set of typedefs to comply with Rule 13.
 */
#ifndef   INC_MISRA_H
#define   INC_MISRA_H

typedef   signed char         SC_8;
typedef   unsigned char       UC_8;
typedef   signed short        SI_16;
typedef   unsigned short      UI_16;
typedef   signed int          SI_32;
typedef   unsigned int        UI_32;
typedef   signed long         SI_64;
typedef   unsigned long       UI_64;
typedef   float               FL_32;
typedef   double              FL_64;

#endif
/******************************************************************/

/*
 *   Rule 69:  Required
 *             --------
 *   Functions with variable numbers of arguments shall not be used.
 */


/*
 *   A simple mechanism for variable argument use suitable for
 *   use in static analysis mimicing the functionality of
 *   stdarg.h without the need to include a possibly unknown
 *   standard version.
 *
 *   See for example, P.J. Plauger, "The Standard C library",
 *   ISBN 0-13-131509-9
 */

#ifndef   _VA_LIST
     #define   _VA_LIST
     typedef   SC_8 *         va_list;
     #define   NULL           (void *)0      /*   #MRULE# 90     */
#endif

#define        va_start(ap, parmN)      \
     ((void)((ap)= (SC_8 *) &(parmN)))       /*   #MRULE# 93     */
#define        va_arg(ap, type)         \
     (*(type *)(ap))                         /*   #MRULE# 93 #MRULE# 96    */
#define        va_end(ap)               \
     ((void)((ap)=0))                        /*   #MRULE# 93     */

void           rule069p(SC_8 *fmt, ...);     /*   #MRULE# 69     */

void
rule069p(SC_8 *fmt, ...)                     /*   #MRULE# 69     */
{
     va_list             ap;
     SC_8                *pc;
     SI_32               ival;

     va_start(ap, fmt);                      /*   #MRULE# 45 #MRULE# 45    */

     for( pc = fmt; (*pc != NULL); pc++ )
     {
          switch(*pc)
          {
          case 'd':
               ival = va_arg(ap, SI_32);     /*   #MRULE# 45     */
               break;    

          default:
               break;
          }
     }

     va_end( ap );                           /*   #MRULE# 45     */
}
