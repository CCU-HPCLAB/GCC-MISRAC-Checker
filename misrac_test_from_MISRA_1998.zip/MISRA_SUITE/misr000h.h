/******************************************************************
 *   MISRA header explicitly embedded by MISRA Conformance architecture.
 *   Revision: $Revision: 1.2 $
 *   Date:     $Date: 2001/06/22 14:42:06 $
 ******************************************************************/
/*
 *   A set of typedefs to comply with Rule 13.
 */
#ifndef   INC_MISRA_H
#define   INC_MISRA_H

typedef   signed char         SC_8;
typedef   unsigned char       UC_8;
typedef   signed short        SI_16;
typedef   unsigned short      UI_16;
typedef   signed int          SI_32;
typedef   unsigned int        UI_32;
typedef   signed long         SI_64;
typedef   unsigned long       UI_64;
typedef   float               FL_32;
typedef   double              FL_64;

#endif
/******************************************************************/
