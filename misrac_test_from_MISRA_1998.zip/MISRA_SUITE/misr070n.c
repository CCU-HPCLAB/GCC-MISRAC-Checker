/******************************************************************
 *   MISRA-C conformance suite.
 *
 *   Copyright:     2001-, Motor Industry Research Association.
 *                  http://www.misra.org.uk/
 *
 *   MISRA is a registered trademark of the Motor Industry Research
 *   Association.
 ******************************************************************
 *   This is part of the official MISRA-C conformance suite.
 *
 *   Acknowledgements:-
 *
 *   This suite is an ongoing project.  It contains source code
 *   and ideas donated in alphabetic order by:-
 *        Andrew Burnard           Land Rover
 *        Les Hatton               Oakwood Computing Associates Ltd.
 *                                 and the University of Kent.
 *        Derek Jones              Knowledge Software Ltd.
 *
 *   In addition, valuable feedback and guidance was provided by
 *   other members of the MISRA steering committee in alphabetic order:-
 *        Paul Burden, Chris Hills, Gavin McCall, Olwen Morgan
 *
 *   Conformance architecture and rule merging done by
 *        Les Hatton               L.Hatton@ukc.ac.uk
 *
 *   Produced and maintained as a project under the auspices of the
 *   Systems and Software Engineering Research Group, Computing
 *   Laboratory, University of Kent, Canterbury, CT2 7NZ, U.K.
 ******************************************************************
 *   Please forward all comments and feedback to Les Hatton.
 ******************************************************************
 *   Distribution:
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation.
 *   
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *   
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA  02111-1307  USA.
 *
 *   PLEASE NOTE THAT THE MASTER COPIES MAINTAINED BY MISRA
 *   CONTAIN AN IDENTIFYING DIGITAL SIGNATURE TO FACILITATE
 *   CONFORMANCE AND EMBEDDED BELOW.
 ******************************************************************
 *DS Digital Signature: 36680
 ******************************************************************/

/******************************************************************
 *   NEGATIVE RULE. A tool must NOT issue messages for this file
 *                  except where explicitly stated due to rule
 *                  crosstalk.  A message corresponding to this
 *                  rule number should NEVER appear in this file
 *                  however.
 ******************************************************************/

/******************************************************************
 *   Revision: $Revision: 1.1 $
 *   Date:     $Date: 2001/10/01 09:14:36 $
 ******************************************************************/

/******************************************************************
 *   MISRA header explicitly embedded by MISRA Conformance architecture.
 *   Revision: $Revision: 1.2 $
 *   Date:     $Date: 2001/06/22 14:42:06 $
 ******************************************************************/
/*
 *   A set of typedefs to comply with Rule 13.
 */
#ifndef   INC_MISRA_H
#define   INC_MISRA_H

typedef   signed char         SC_8;
typedef   unsigned char       UC_8;
typedef   signed short        SI_16;
typedef   unsigned short      UI_16;
typedef   signed int          SI_32;
typedef   unsigned int        UI_32;
typedef   signed long         SI_64;
typedef   unsigned long       UI_64;
typedef   float               FL_32;
typedef   double              FL_64;

#endif
/******************************************************************/

/*
 *   Rule 70:  Required
 *             --------
 *   Functions shall not call themselves, either directly or indirectly.
 */


extern    void      rule070n(void);
extern    void      rule070na(void);

extern void    rule070nb(void);
extern void    (* const prule070nb)(void) = rule070nb;

void
rule070n(void)
{
     rule070na();                            /*   OK             */
}
