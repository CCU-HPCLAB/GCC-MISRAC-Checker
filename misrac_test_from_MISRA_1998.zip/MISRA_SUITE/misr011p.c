/******************************************************************
 *   MISRA-C conformance suite.
 *
 *   Copyright:     2001-, Motor Industry Research Association.
 *                  http://www.misra.org.uk/
 *
 *   MISRA is a registered trademark of the Motor Industry Research
 *   Association.
 ******************************************************************
 *   This is part of the official MISRA-C conformance suite.
 *
 *   Acknowledgements:-
 *
 *   This suite is an ongoing project.  It contains source code
 *   and ideas donated in alphabetic order by:-
 *        Andrew Burnard           Land Rover
 *        Les Hatton               Oakwood Computing Associates Ltd.
 *                                 and the University of Kent.
 *        Derek Jones              Knowledge Software Ltd.
 *
 *   In addition, valuable feedback and guidance was provided by
 *   other members of the MISRA steering committee in alphabetic order:-
 *        Paul Burden, Chris Hills, Gavin McCall, Olwen Morgan
 *
 *   Conformance architecture and rule merging done by
 *        Les Hatton               L.Hatton@ukc.ac.uk
 *
 *   Produced and maintained as a project under the auspices of the
 *   Systems and Software Engineering Research Group, Computing
 *   Laboratory, University of Kent, Canterbury, CT2 7NZ, U.K.
 ******************************************************************
 *   Please forward all comments and feedback to Les Hatton.
 ******************************************************************
 *   Distribution:
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation.
 *   
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *   
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA  02111-1307  USA.
 *
 *   PLEASE NOTE THAT THE MASTER COPIES MAINTAINED BY MISRA
 *   CONTAIN AN IDENTIFYING DIGITAL SIGNATURE TO FACILITATE
 *   CONFORMANCE AND EMBEDDED BELOW.
 ******************************************************************
 *DS Digital Signature: 62531
 ******************************************************************/

/******************************************************************
 *   POSITIVE RULE.  A tool must detect the occurrences marked:-
 *
 *   MRULE parenthesized by #...#  followed by the rule number.
 *   This pattern is used by the conformance suite infrastructure
 *   to build a calibration compliance matrix.
 ******************************************************************/

/******************************************************************
 *   Revision: $Revision: 1.3 $
 *   Date:     $Date: 2001/12/12 12:55:50 $
 ******************************************************************/
/******************************************************************
 *   MISRA header explicitly embedded by MISRA Conformance architecture.
 *   Revision: $Revision: 1.2 $
 *   Date:     $Date: 2001/06/22 14:42:06 $
 ******************************************************************/
/*
 *   A set of typedefs to comply with Rule 13.
 */
#ifndef   INC_MISRA_H
#define   INC_MISRA_H

typedef   signed char         SC_8;
typedef   unsigned char       UC_8;
typedef   signed short        SI_16;
typedef   unsigned short      UI_16;
typedef   signed int          SI_32;
typedef   unsigned int        UI_32;
typedef   signed long         SI_64;
typedef   unsigned long       UI_64;
typedef   float               FL_32;
typedef   double              FL_64;

#endif
/******************************************************************/

/*
 *   Rule 11:  Required
 *             --------
 *   Identifiers (internal and external) shall not rely on significance
 *   of more than 31 characters.  Furthermore the compiler/linker shall
 *   be checked to ensure that 31 character significance and case
 *   sensitivity are supported for external identifiers.
 */


static    UI_32 
     T234567890123456789012345678901A = 1u;
static    UI_32 
     T234567890123456789012345678901B = 26u;      /*   #MRULE# 11     */

extern    UI_32 
     T234567890123456789012345678902A(void);
extern    UI_32 
     T234567890123456789012345678902B(void);      /*   #MRULE# 11     */

void
T234567890123456789012345678903A(void);

void
T234567890123456789012345678903A(void)
{
     UI_32 
     T234567890123456789012345678903B;            /*   #MRULE# 11     */
}
